import { ReadMorePipe } from './read-more.pipe';

describe('ReadMorePipe', () => {
  it('create an instance', () => {
    const pipe = new ReadMorePipe();
    expect(pipe).toBeTruthy();
  });
});
