import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CurrencyconvertService {

  currencyData:any = {};
  currentCurrencyData:any={};
constructor(){

  }
  
}
