import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saved-address',
  templateUrl: './saved-address.component.html',
  styleUrls: ['./saved-address.component.css']
})
export class SavedAddressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
