import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-order',
  templateUrl: './profile-order.component.html',
  styleUrls: ['./profile-order.component.css']
})
export class ProfileOrderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
