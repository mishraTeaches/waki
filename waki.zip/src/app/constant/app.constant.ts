export const appConstant={
     //"baseUrl":"http://localhost:4200/",
    "baseUrl":'http://13.126.131.184:5050/',
    // "baseUrl":'http://192.168.1.35:5050/',
   // "baseUrl":'http://52.27.53.102:3113/',
    "translateUrl":'assets/translate/',
    "rtl":"SA",
    "color":"red"
}